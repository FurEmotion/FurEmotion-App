import 'package:flutter/material.dart';

class Style {
  static const TextStyle titleText = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    color: Colors.brown,
  );
}
